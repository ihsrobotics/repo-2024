from ctypes import CDLL
kipr = "/usr/local/lib/libkipr.so"
k = CDLL(kipr)
import sys

sys.path.append("/home/pi/Documents/IME_files/purpleNoodle/include")
from sensor_shortcuts import *
from constants import *

def retry_connect(n):
        for i in range(n):
                print("Attempt to connect")
                success = k.create_connect_once()
                if success:
                        print("Connected ^w^")
                        return True
        return False


def move_servo_slowly(port, end_position, delay=0):
    position = k.get_servo_position(port)
    if end_position == position:
        return
    elif delay == 0:
        k.set_servo_position(port, end_position)
        k.msleep(100)
        return
    while k.get_servo_position(port) < end_position and k.get_servo_position(port)+5 < 2048:
        position = k.get_servo_position(port)+5
        k.set_servo_position(port, position)
        k.msleep(delay)
    while k.get_servo_position(port) > end_position and k.get_servo_position(port)-5 > 0:
        position = k.get_servo_position(port)-5
        k.set_servo_position(port, position)
        k.msleep(delay)
    k.set_servo_position(port, end_position)
    k.msleep(100)
"""
success = retry_connect(5) ## connects to bot, tries 5 times
if not success:
	print("Failed to connect!!!")
	print_battery_info()
	start_time = k.seconds()
"""
k.create_connect_once()
k.create_safe()
k.enable_servos()

move_servo_slowly(CLAW_PORT, CLAW_OPEN, 5)
move_servo_slowly(ARM_PORT, ARM_DOWN_START, 5)
move_servo_slowly(ROD_PORT, ROD_SIDE,5)

#k.mav(SWEEPER_PORT, 0)
import purple_noodles #checks for syntax problems in main