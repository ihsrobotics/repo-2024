from ctypes import CDLL
kipr = "/usr/local/lib/libkipr.so"
k = CDLL(kipr)
#sensor shortcuts
def rod():
	return k.analog(1)
def left_side():
	return k.get_create_lcliff_amt()
def left_front():
	return k.get_create_lfcliff_amt()
def right_side():
	return k.get_create_rcliff_amt()
def right_front():
	return k.get_create_rfcliff_amt()
def drive(left_speed, right_speed):
	k.create_drive_direct(left_speed, right_speed)
	return
def farthest_left_distance():
	return k.get_create_llight_bump_amt()
def middle_left_distance():
	return k. get_create_lflightbump_amt()
def foward_left_distance():
	return k.get_create_lclightbump_amt()
def farthest_right_distance():
        return k.get_create_rlight_bump_amt()
def middle_right_distance():
        return k. get_create_rflightbump_amt()
def foward_right_distance():
        return k.get_create_rclightbump_amt()