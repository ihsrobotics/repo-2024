import cv2
import numpy as np

from time import time

from config_loader import *

def execution_time_decorator(func):
    def wrapper(*args, **kwargs):
        start_time = time()
        result = func(*args, **kwargs)
        end_time = time()
        print(f"Function {func.__name__} took {end_time - start_time} seconds to execute")
        return result
    return wrapper

class ColorRange:
    def __init__(self, lower: list[int], upper: list[int]) -> None:
        self.lower = np.array(lower, dtype="uint8")
        self.upper = np.array(upper, dtype="uint8")

    def mask(self, image: cv2.typing.MatLike):
        return cv2.inRange(image, self.lower, self.upper)


class Camera:
    def __init__(self, port: int, color_ranges: dict[str, ColorRange]) -> None:
        self.color_ranges = color_ranges
        self.video = cv2.VideoCapture(port)
        if not self.video.isOpened():
            raise Exception("cannot get video")
        self.video.read()
        print("video opened")

    def get_frame(self) -> tuple[bool, cv2.typing.MatLike]:
        return self.video.read()

    def normalize(self, image: cv2.typing.MatLike) -> cv2.typing.MatLike:
        lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        l_norm = cv2.normalize(l, None, 0, 255, cv2.NORM_MINMAX)
        lab = cv2.merge([l_norm, a, b])
        normalized_image = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
        return normalized_image

    def get_hough_lines(
        self,
        image: cv2.typing.MatLike,
        crop_top: int = default_camera_crop_top,
        crop_bottom: int = default_camera_crop_bottom,
        crop_left: int = default_camera_crop_left,
        crop_right: int = default_camera_crop_right,
        canny_thresh1: int = default_canny_thresh1,
        canny_thresh2: int = default_canny_thresh2,
        aperture_size: int = default_aperture_size,
        hough_lines_rho_resolution: int = default_hough_lines_rho_resolution,
        hough_lines_thresh: int = default_hough_lines_thresh,
        # for calculating the best line
        slope_exponent: int = default_hough_lines_optimization_slope_exponent,
        distance_coefficient: int = default_hough_lines_optimization_distance_coefficient,
    ) -> list[tuple[int, int, int, int, float, float]]:
        height, width = image.shape[:2]
        image = image[crop_top : height - crop_bottom, crop_left : width - crop_right]
        image = self.normalize(image)
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(
            gray_image, canny_thresh1, canny_thresh2, apertureSize=aperture_size
        )
        lines = cv2.HoughLines(
            edges, hough_lines_rho_resolution, np.pi / 180, hough_lines_thresh
        )
        if not hasattr(lines, "__iter__"):
            print("no lines found")
            return []
        hough_lines = []
        for r_theta in lines:
            arr = np.array(r_theta[0], dtype=np.float64)
            r, theta = arr
            a = np.cos(theta)
            b = np.sin(theta)
            x0 = a * r
            y0 = b * r
            x1 = int(x0 + 1000 * (-b))
            y1 = int(y0 + 1000 * (a))
            x2 = int(x0 - 1000 * (-b))
            y2 = int(y0 - 1000 * (a))

            slope = a / -b if abs(b) != 0 else float("inf")
            hough_lines.append((x1, y1, x2, y2, slope, y0))

        hough_lines = sorted(
            hough_lines,
            key=lambda line: (
                abs(line[4] + 1) ** slope_exponent - line[5] * distance_coefficient
            ),
        )
        return hough_lines

    def draw_hough_lines(
        self,
        image: cv2.typing.MatLike,
        crop_top: int = default_camera_crop_top,
        crop_bottom: int = default_camera_crop_bottom,
        crop_left: int = default_camera_crop_left,
        crop_right: int = default_camera_crop_right,
        canny_thresh1: int = default_canny_thresh1,
        canny_thresh2: int = default_canny_thresh2,
        aperture_size: int = default_aperture_size,
        hough_lines_rho_resolution: int = default_hough_lines_rho_resolution,
        hough_lines_thresh: int = default_hough_lines_thresh,
        # for calculating the best line
        slope_exponent: int = default_hough_lines_optimization_slope_exponent,
        distance_coefficient: int = default_hough_lines_optimization_distance_coefficient,
    ) -> cv2.typing.MatLike:
        hough_lines = self.get_hough_lines(
            image,
            crop_top,
            crop_bottom,
            crop_left,
            crop_right,
            canny_thresh1,
            canny_thresh2,
            aperture_size,
            hough_lines_rho_resolution,
            hough_lines_thresh,
            slope_exponent,
            distance_coefficient,
        )
        if len(hough_lines) == 0:
            return image.astype(np.uint8)
        for index, line in enumerate(hough_lines):
            if index == 0:
                cv2.line(image, (line[0], line[1]), (line[2], line[3]), (0, 255, 0), 2)
                cv2.putText(
                    image,
                    str(line[5]),
                    (100, 50),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    1,
                    (255, 0, 0),
                    2,
                    cv2.LINE_AA,
                )
                cv2.putText(
                    image,
                    str(line[4]),
                    (100, 100),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    1,
                    (255, 255, 255),
                    2,
                    cv2.LINE_AA,
                )
            else:
                cv2.line(
                    image,
                    (line[0], line[1]),
                    (line[2], line[3]),
                    (0, 0, 255),
                    2,
                )
        return image.astype(np.unit8)

    @execution_time_decorator
    def get_live_hough_line_distance(
        self,
        crop_top: int = default_camera_crop_top,
        crop_bottom: int = default_camera_crop_bottom,
        crop_left: int = default_camera_crop_left,
        crop_right: int = default_camera_crop_right,
        canny_thresh1: int = default_canny_thresh1,
        canny_thresh2: int = default_canny_thresh2,
        aperture_size: int = default_aperture_size,
        hough_lines_rho_resolution: int = default_hough_lines_rho_resolution,
        hough_lines_thresh: int = default_hough_lines_thresh,
        # for calculating the best line
        slope_exponent: int = default_hough_lines_optimization_slope_exponent,
        distance_coefficient: int = default_hough_lines_optimization_distance_coefficient,
    ) -> tuple[float, float]:
        ret, frame = self.video.read()
        if not ret:
            raise Exception("cannot get frame")
        hough_lines = self.get_hough_lines(
            frame,
            crop_top,
            crop_bottom,
            crop_left,
            crop_right,
            canny_thresh1,
            canny_thresh2,
            aperture_size,
            hough_lines_rho_resolution,
            hough_lines_thresh,
            slope_exponent,
            distance_coefficient,
        )
        if len(hough_lines) == 0:
            return (-1, float('inf'))
        return (hough_lines[0][5], hough_lines[0][4])

    def get_color_bounding_box(
        self, image: cv2.typing.MatLike, color: str, kernel_size: int, iterations: int
    ) -> list[tuple[int, int, int, int]]:
        if not color in self.color_ranges:
            raise Exception("invalid color key")
        kernel = np.ones((kernel_size), np.uint8)
        image = self.normalize(image)
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        mask = self.color_ranges[color].mask(hsv)
        mask = cv2.erode(mask, kernel, iterations=iterations)
        mask = cv2.dilate(mask, kernel, iterations=iterations)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        boxes = []
        for c in contours:
            boxes.append(cv2.boundingRect(c))
        boxes = sorted(boxes, key=lambda box: (box[2] * box[3]), reverse=True)
        return boxes

    def get_live_color_bounding_box_center(
        self,
        color: str,
        kernel_size: int = 5,
        iterations: int = 2,
    ) -> tuple[float, float]:
        ret, frame = self.video.read()
        if not ret:
            raise Exception("cannot get frame")
        bounding_boxes = self.get_color_bounding_box(
            frame, color, kernel_size, iterations
        )
        if len(bounding_boxes) == 0:
            return (-1, -1)
        return (
            bounding_boxes[0][0] + bounding_boxes[0][2] / 2,
            bounding_boxes[0][1] + bounding_boxes[1][3] / 2,
        )

    def close(self):
        self.video.release()
        cv2.destroyAllWindows()
