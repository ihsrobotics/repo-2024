from ctypes import CDLL
kipr = "/usr/local/lib/libkipr.so"
k = CDLL(kipr)

from config_loader import *
from time import time

analog = k.analog
digital = k.digital

left_side = k.get_create_lcliff_amt
left_front = k.get_create_lfcliff_amt
right_side = k.get_create_rcliff_amt
right_front = k.get_create_rfcliff_amt

create_drive_direct = k.create_drive_direct

def drive(left_speed, right_speed):
    create_drive_direct(left_speed, right_speed)
    return

farthest_left_distance = k.get_create_llightbump_amt
middle_left_distance = k.get_create_lflightbump_amt
forward_left_distance = k.get_create_lclightbump_amt
farthest_right_distance = k.get_create_rlightbump_amt
middle_right_distance = k.get_create_rflightbump_amt
forward_right_distance = k.get_create_rclightbump_amt

create_connect_once = k.create_connect_once
create_disconnect = k.create_disconnect

disable_servos = k.disable_servos
ao = k.ao

set_servo_position = k.set_servo_position
get_servo_position = k.get_servo_position
move_servo = k.set_servo_position
msleep = k.msleep

def retry_connect(n):
    for i in range(n):
        print("attempt to connect")
        success = create_connect_once()
        if success:
            print("connected")
            return True
    return False

def cleanup():
    k.create_safe()
    create_disconnect()
    disable_servos()
    ao()

# higher step value = faster servo move
def servo(port, end_position, delay=0):
    position = get_servo_position(port)
    if end_position == position:
        return
    elif delay == 0:
        set_servo_position(port, end_position)
        msleep(100)
        return
    while get_servo_position(port) < end_position and get_servo_position(port)+5 < 2048:
        position = get_servo_position(port)+5
        set_servo_position(port, position)
        msleep(delay)
    while get_servo_position(port) > end_position and get_servo_position(port)-5 > 0:
        position = get_servo_position(port)-5
        set_servo_position(port, position)
        msleep(delay)
    set_servo_position(port, end_position)

def move_servo_slowly(port, end_position, step=2):
    start_position = k.get_servo_position(port)
    if end_position == start_position:
        return
    print(start_position)
    if start_position > end_position:
        step = -step
    interval = range(start_position, end_position, step)
    k.enable_servo(port)
    for position in interval:
        k.set_servo_position(port, position)
        k.msleep(10)
    k.set_servo_position(port, end_position)
    k.msleep(100)

def drive_to_line(left_speed, right_speed, left_sensor=left_front, right_sensor=right_front):
    detect = 0
    print(left_sensor(), right_sensor())
    while left_sensor() > BLACK and right_sensor() > BLACK:
        drive(left_speed, right_speed)
    if detect < 2:
        while left_sensor() > BLACK:
            drive(left_speed, 0)
        detect += 1
        print(detect)
        while(right_sensor() > BLACK):
            drive(0, right_speed)
        detect += 1
        drive(0, 0)
        return

def line_follow(port, seconds):
    end_time = seconds*1000
    start = time()
    while time() - start < end_time:
        if port() < BLACK:
            create_drive_direct(250, 150)
        if port() > BLACK:
            create_drive_direct(150, 250)

def print_battery_info():
    print("Capacity", k.get_create_battery_capacity())
    print("Charge", k.get_create_battery_charge())
    print("Percentage", k.get_create_battery_charge() / k.get_create_battery_capacity() * 100)

def turn_180(facing_third_pipe=False):
    #Square up with line
    drive_to_line(150, 150, left_side, right_side)
    drive(-150, -150)
    k.msleep(300)
    #drive_to_line(150, 150, left_side, right_side)
    #Drive until side tophat (on the left of bot) reaches the white edge of line
    while k.analog(SIDE_TOPHAT_PORT) > SENSOR_BLACK:
        drive(150, 150)
    #Drive back arbitrary amt
    drive(150, 150)
    k.msleep(1150)
    """#THIS STOP/MSLEEP IS TO TEST IF THE ROBOT IS ACTUALLY TURNING 180 DEG ACCURATELY
    drive(0, 0)
    k.msleep(5000)"""
    #Rotate until side sensor reaches black line (180 deg)
    drive(150, -150)
    k.msleep(500)
    while k.analog(SIDE_TOPHAT_PORT) < SENSOR_BLACK:
        drive(150, -150)
    #If facing third pipe, continue (will pass over the vert line)
    if facing_third_pipe == True:
        drive(150, -150)
        k.msleep(1000)
        while k.analog(SIDE_TOPHAT_PORT) < SENSOR_BLACK:
            drive(150, -150)
    while k.analog(SIDE_TOPHAT_PORT) > SENSOR_BLACK:
        drive(150, -150)
    #Back up
    drive(-150, 150)
    k.msleep(15)
    ao()
    #k.msleep(250)
    #drive_to_line(150, 150, left_side, right_side) causes problem 
    drive(-150, -150)
    k.msleep(500)
    #Square up
    drive_to_line(150, 150, left_side, right_side)
    drive(-150, -150)
    k.msleep(300)
    """while k.analog(SIDE_TOPHAT_PORT) > SENSOR_BLACK:
        drive(-150, -150)"""
    while k.analog(SIDE_TOPHAT_PORT) > SENSOR_BLACK:
        drive(150, 150)
    drive(-150, -150)
    k.msleep(125)
    ao()
    




