import json

configs = {}

def load_configs():
    global configs
    with open('/home/pi/Documents/IME_files/BigBotLavaTubes2024/include/config.json') as f:
        configs = json.load(f)

load_configs()

CLAW_PORT = configs['clawPort']
ARM_PORT = configs['armPort']
SWEEPER_TOPHAT_PORT = configs['sweeperTophatPort']
SIDE_SERVO_PORT = configs['sideServoPort']
SIDE_TOPHAT_PORT = configs['sideTophatPort']

ARM_STRAIGHT_UP = configs['armStraightUp']
ARM_STRAIGHT = configs['armStraight']
ARM_GRAB = configs['armGrab']
ARM_DOWN = configs['armDown']
ARM_ON_RACK = configs['armOnRack']

CLAW_OPEN = configs['clawOpen']
CLAW_CLOSED = configs['clawClosed']
CLAW_GRAB = configs['clawGrab']

SIDE_LEFT = configs['sideLeft']
SIDE_RIGHT = configs['sideRight']
SIDE_CENTER = configs['sideCenter']

SENSOR_BLACK = configs['sensorBlack']
SENSOR_WHITE = configs['sensorWhite']
BLACK = configs['black']

LAVA_RESET = configs['lavaReset']
LAVA_OPEN = configs['lavaOpen'] #value might depend on quality of rubber bands
LARGE_LAVA_HEIGHT = configs['largeLavaHeight']
MEDIUM_LAVA_HEIGHT = configs['mediumLavaHeight']
SHORT_LAVA_HEIGHT = configs['shortLavaHeight']

orange_lower: list[int] = [value for _, value in configs["orange"].items()][:3]
orange_upper: list[int] = [value for _, value in configs["orange"].items()][3:]

yellow_lower: list[int] = [value for _, value in configs["yellow"].items()][:3]
yellow_upper: list[int] = [value for _, value in configs["yellow"].items()][3:]

purple_lower: list[int] = [value for _, value in configs["purple"].items()][:3]
purple_upper: list[int] = [value for _, value in configs["purple"].items()][3:]

blue_lower: list[int] = [value for _, value in configs["blue"].items()][:3]
blue_upper: list[int] = [value for _, value in configs["blue"].items()][3:]

red_lower: list[int] = [value for _, value in configs["red"].items()][:3]
red_upper: list[int] = [value for _, value in configs["red"].items()][3:]

green_lower: list[int] = [value for _, value in configs["green"].items()][:3]
green_upper: list[int] = [value for _, value in configs["green"].items()][3:]

light_green_lower: list[int] = [value for _, value in configs["light_green"].items()][:3]
light_green_upper: list[int] = [value for _, value in configs["light_green"].items()][3:]

default_canny_thresh1 = configs["default_canny_thresh1"]
default_canny_thresh2 = configs["default_canny_thresh2"]
default_aperture_size = configs["default_aperture_size"]
default_hough_lines_rho_resolution = configs["default_hough_lines_rho_resolution"]
default_hough_lines_thresh = configs["default_hough_lines_thresh"]

default_hough_lines_optimization_slope_exponent = configs["default_hough_lines_optimization_slope_exponent"]
default_hough_lines_optimization_distance_coefficient = configs["default_hough_lines_optimization_distance_coefficient"]

default_camera_crop_bottom = configs["default_camera_crop_bottom"]
default_camera_crop_top = configs["default_camera_crop_top"]
default_camera_crop_left = configs["default_camera_crop_left"]
default_camera_crop_right = configs["default_camera_crop_right"]

lavatubes_camera_crop_right = configs["lavatubes_camera_crop_right"]
lavatubes_camera_crop_bottom = configs["lavatubes_camera_crop_bottom"]
lavatubes_hough_lines_rho_resolution = configs["lavatubes_hough_lines_rho_resolution"]
lavatubes_hough_lines_thresh = configs["lavatubes_hough_lines_thresh"]
lavatubes_hough_lines_optimization_slope_exponent = configs["lavatubes_hough_lines_optimization_slope_exponent"]
lavatubes_hough_lines_optimization_distance_coefficient = configs["lavatubes_hough_lines_optimization_distance_coefficient"]