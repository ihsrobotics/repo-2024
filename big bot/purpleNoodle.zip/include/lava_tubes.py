import ihs_bindings
import sys
# print("debugger")
# import time
# time.sleep(3)
# add ../include to the import path
sys.path.append("/home/pi/Documents/IME_files/purpleNoodle/include/lava_tubes_include")

# print("debugger 2")
# time.sleep(3)

from kipr_functions import *
from camera import *
from constants import *
from sweeper import *
from threading import Thread
# from config_loader import *

def shake_straight(speed, duration=250):
    amount = 0
    while amount < 5:
        drive(-speed, -speed)
        k.msleep(duration)
        drive(speed, speed)
        k.msleep(duration)
        amount += 1
    drive(0, 0)

def shake_turn(speed, duration=100):
    amount = 0
    while amount < 5:
        drive(speed, -speed)
        k.msleep(duration)
        drive(-speed, speed)
        k.msleep(2 * duration)
        drive(speed, -speed)
        k.msleep(duration)
        amount += 1
    drive(0, 0)

def claw_shake():
    amount = 0
    while amount < 5:
        servo(CLAW_PORT, LAVA_OPEN)
        k.msleep(10)
        servo(CLAW_PORT, CLAW_GRAB)
        k.msleep(10)
        amount += 1
    servo(CLAW_PORT, LAVA_OPEN)

def lava_tubes_main():
    move_servo_slowly(ARM_PORT, LARGE_LAVA_HEIGHT, 5)
    #move side servo to 1297, black rod should be alined with far side of black tape

    #large lava tube
    servo(CLAW_PORT, CLAW_GRAB)
    move_servo_slowly(ARM_PORT, LARGE_LAVA_HEIGHT, 5)
    
    move_servo_slowly(SIDE_SERVO_PORT, 570, 5) #orginally 620, 528
    drive(30, -30)
    while k.analog(SIDE_TOPHAT_PORT) < SENSOR_BLACK:
        pass
    drive(0, 0)
    servo(CLAW_PORT, LAVA_OPEN)
    shake_straight(100) # first poodle has more friction from extra top poodle, needs more speed for effective shake
    shake_turn(65, 100)

    move_servo_slowly(ARM_PORT, 213, 5)
    servo(CLAW_PORT, CLAW_GRAB)
    move_servo_slowly(ARM_PORT, LARGE_LAVA_HEIGHT, 1)

    #medium lava tube
    move_servo_slowly(SIDE_SERVO_PORT, 760, 5) #orginally 769    
    ihs_bindings.encoder_turn_degrees_v2(200, -15)
    drive(20, -20)
    move_servo_slowly(ARM_PORT, MEDIUM_LAVA_HEIGHT, 5)
    while k.analog(SIDE_TOPHAT_PORT) < SENSOR_BLACK:
        pass
    drive(0, 0)
    drive(140, 140) #70, 70
    k.msleep(125) #250
    drive(0, 0)
    move_servo_slowly(ARM_PORT, LARGE_LAVA_HEIGHT, 5) # move to clear the other pipe and allow claw to open fully
    servo(CLAW_PORT, LAVA_OPEN)
    k.msleep(500) # give time for poodle to fall out
    shake_straight(75)
    shake_turn(65, 100)

    

    #large lava tube AGAIN!!!
    """
    k.enable_servos()
    servo(ARM_PORT, LARGE_LAVA_HEIGHT)
    move_servo_slowly(ARM_PORT, LARGE_LAVA_HEIGHT, 10)

    move_servo_slowly(SIDE_SERVO_PORT, 528, 5) #orginally 620
    drive(30, -30)
    while k.analog(SIDE_TOPHAT_PORT) < SENSOR_BLACK:
        pass
    
    drive(0, 0)

    move_servo_slowly(CLAW_PORT, LAVA_OPEN, 5)
    shake_straight(100) # first poodle has more friction from extra top poodle, needs more speed for effective shake
    shake_turn(65)
    """

    #throws the jannis away from lava tubes
    ihs_bindings.encoder_turn_degrees_v2(145, -100)
    servo(CLAW_PORT, CLAW_OPEN)
def lava_tubes_pathing():
    camera = Camera(0, color_ranges)
    prev_distance = []
    move_servo_slowly(ARM_PORT, ARM_STRAIGHT_UP, 10)

    while(analog(SWEEPER_TOPHAT_PORT) > 1600):
        create_drive_direct(0, -50)
    create_drive_direct(0, 0)

    start_time = time()
    is_sweeping = True
    sweep_thread = sweep_async()
    while(time() - start_time < 10):
        distance, slope = camera.get_live_hough_line_distance(
            crop_right=lavatubes_camera_crop_right,
            crop_bottom=lavatubes_camera_crop_bottom,
            hough_lines_rho_resolution=lavatubes_hough_lines_rho_resolution,
            hough_lines_thresh=lavatubes_hough_lines_thresh,
            slope_exponent=lavatubes_hough_lines_optimization_slope_exponent,
            distance_coefficient=lavatubes_hough_lines_optimization_distance_coefficient
        )
        print(distance, slope)
        # outlier / noise
        if distance > 225: 
            sweep_async()
        prev_distance.append(distance)
        if sum(prev_distance[-5:]) >= 114*5 and slope < 1:
            print("target reached", prev_distance[-5:])
            create_drive_direct(0, 0)
            break
        if(analog(SWEEPER_TOPHAT_PORT) < 1600):
            create_drive_direct(-150, -100)
        else:
            create_drive_direct(-100, -150)
        

        
    create_drive_direct(0, 0)
    camera.close()

color_ranges = {
    "orange": ColorRange(orange_lower, orange_upper),
    "yellow": ColorRange(yellow_lower, yellow_upper),
    "purple": ColorRange(purple_lower, purple_upper),
    "blue": ColorRange(blue_lower, blue_upper),
    "red": ColorRange(red_lower, red_upper),
    "green": ColorRange(green_lower, green_upper),
    "light_green": ColorRange(light_green_lower, light_green_upper)
}
def lava_tubes_init():
    camera = Camera(0, color_ranges)
    prev_distance = []
if __name__ == "__main__":
    k.enable_servos()
    retry_connect(5)
    lava_tubes_init()

    start_time = time()
    """ DONT DELETE PLEASE MIGHT BREAK CODE
    move_servo_slowly(ARM_PORT, ARM_STRAIGHT_UP, 10)

    while(analog(SWEEPER_TOPHAT_PORT) > 1600):
        create_drive_direct(0, -50)
    create_drive_direct(0, 0)

    start_time = time()

    while(time() - start_time < 10):
        distance, slope = camera.get_live_hough_line_distance(
            crop_right=lavatubes_camera_crop_right,
            crop_bottom=lavatubes_camera_crop_bottom,
            hough_lines_rho_resolution=lavatubes_hough_lines_rho_resolution,
            hough_lines_thresh=lavatubes_hough_lines_thresh,
            slope_exponent=lavatubes_hough_lines_optimization_slope_exponent,
            distance_coefficient=lavatubes_hough_lines_optimization_distance_coefficient
        )
        print(distance, slope)
        # outlier / noise
        if distance > 225: continue
        prev_distance.append(distance)
        if sum(prev_distance[-5:]) >= 114*5 and slope < 1:
            print("target reached", prev_distance[-5:])
            create_drive_direct(0, 0)
            break
        if(analog(SWEEPER_TOPHAT_PORT) < 1600):
            create_drive_direct(-150, -100)
        else:
            create_drive_direct(-100, -150)
        
    create_drive_direct(0, 0)
    camera.close()
    """
    #lava_tubes_pathing()
    #lava_tubes_main()
    print("time:", time() - start_time)
    cleanup()