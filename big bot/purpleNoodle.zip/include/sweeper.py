from constants import *
from threading import Thread
import time
is_sweeping = False
def sweep():
	global is_sweeping
	if is_sweeping:
		return
	is_sweeping = True
	speed = 1000
	k.mav(SWEEPER_PORT, speed)
	k.msleep(600)
	k.mav(SWEEPER_PORT, 0)
	k.mav(SWEEPER_PORT, -speed)
	k.msleep(600)
	k.mav(SWEEPER_PORT, 0)
	k.mav(SWEEPER_PORT, 0)
	is_sweeping = False
	
def sweep_async():
    t = Thread(target=sweep)
    t.start()
    return t

sweep_async()