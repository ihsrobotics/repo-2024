from constants import *
from threading import Thread
is_sweeping = False
def sweep_right():
	global is_sweeping
	if is_sweeping:
		return
	is_sweeping = True
	k.set_servo_position(SWEEPER_PORT, SWEEPER_RIGHT)
	k.msleep(300)
	is_sweeping = False
def sweep_left():
	global is_sweeping
	if is_sweeping:
		return
	is_sweeping = True
	k.set_servo_position(SWEEPER_PORT, SWEEPER_LEFT)
	k.msleep(300)
	is_sweeping = False
def sweep():
	if k.get_servo_position(SWEEPER_PORT) == SWEEPER_LEFT:
		sweep_right()
		sweep_left()
	elif k.get_servo_position(SWEEPER_PORT) == SWEEPER_RIGHT:
		sweep_left()
		sweep_right()
	else:
		sweep_left()
def sweep_async():
    if is_sweeping:
        return
    t = Thread(target=sweep)
    t.start()
    return t
def sweep_center():
	k.set_servo_position(SWEEPER_PORT, SWEEPER_CENTER)
def sweep_loop():
	pass